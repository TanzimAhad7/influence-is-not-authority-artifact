# A14 Minimal P1×P3 Factorial Package

This is the USENIX-focused replacement for the unscored 856-condition A14-V3.1 design.

## Pre-outcome order

Keep vLLM OFF.

```bash
export A14M_TOKENIZER="meta-llama/Llama-3.3-70B-Instruct"
bash A14M_RUN_PREFREEZE.sh "$(pwd)"
```

Expected:

- 24 bases
- 96 conditions
- 96 factorial authorization-equivalence edges
- 16 human-audit pairs
- 864 Llama logical scoring-plan rows
- 480 Gemma logical scoring-plan rows
- exact four-cell prompt-token equality within every base
- zero future execution-ID leakage into descendants
- zero scorer/model/API calls

Then run the 16-pair human construct audit:

```bash
python3 A14M_01_human_audit_cli.py
```

Only if it ends `pass=16 fail=0 pending=0`, freeze:

```bash
python3 A14M_02_freeze_protocol.py
```

Do not score before the final freeze.

## Primary scoring after freeze

Start the Llama scorer on GPUs 2,3:

```bash
bash start_A14M_Llama_vLLM.sh
```

Wait for READY, then preflight:

```bash
python3 A14M_03_score.py --scorer-label llama --preflight-only
```

Then score:

```bash
python3 A14M_03_score.py --scorer-label llama | tee a14m_llama_score.log
```

Analyze:

```bash
python3 A14M_04_analyze.py
cat a14_minimal_factorial/analysis/REPORT.md
```

Gemma source-fidelity replication is secondary and should be run only after preserving the completed primary Llama artifacts; it uses the already-frozen code and corpus.
