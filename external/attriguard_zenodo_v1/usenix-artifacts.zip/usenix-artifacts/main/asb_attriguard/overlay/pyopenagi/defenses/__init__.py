"""Defense modules for ASB."""
